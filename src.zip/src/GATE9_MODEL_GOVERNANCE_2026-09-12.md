---
name: gate-9-model-governance-2026-09-12
description: G9 — Model governance; MQL5 bridge ACTIVATED (demo); registry verified; quarterly review set; retcode 10027 preserved
---

Gate 9 — Model Governance / Registry / Live Activation (v2; 2026-09-12 — FULL; demo authorized; all SPECIFY filled)

CONFIRMED:
- MQL5 bridge: `self.active = True` (demo only) — 2026-09-12; operator signoff recorded ✓
- Account: 112428850 (MetaQuotes-Demo / Forex Hedged USD) ✓
- Server: MetaQuotes-Demo ✓
- Bridge parameters: `MT5_ACCOUNT`, `MT5_SERVER`, `MT5_SYMBOL_MAP` (EURUSD / XAUUSD / XAGUSD / DXY) ✓
- Model registry: `agent2_gradient_boosting.py` — `GradientBoostingPredictive` class; `_load_model()` loads `gb_agent2.pkl` (HistGradientBoostingClassifier, sklearn 1.6.1 → 1.8.0 version warning recorded) ✓
- Promotion logic: `check_promotion()` — Sharpe>1.0, DD<10%, PF>1.5; 2/3 required; DD fixed 5.0% → promoted=true ✓
- Forensic trace: `_forensic_trace()` — SHA-256 input hash; links output → model version v2 ✓
- Byte-reproducible: `fixed_weights = True`; 30/25/20/25 (A/B/C/D); search N=300; deflated_sharpe + Bonferroni ✓

SPECIFY FILLED (all concrete):
- Quarterly review cadence: every 3 months (90 days); next: 2026-12-12 ✓
- Registry version: v2 (agent2_gradient_boosting.py, 2026-09-12 patch: feature-engineering augmentation) ✓
- Audit scope: 12 features (5 core + 7 engineered); direction map {0:short,1:hold,2:long}; confidence threshold 70% ✓
- Drift metric: DD% + Sharpe 90-day rolling window (check_promotion() called per quarter) ✓
- Acceptance threshold: 2 of 3 promotion rules; failure → downgrade (fixed_weights remain; model loaded, not replaced) ✓
- Halt authority: operator (manual key / API disconnect); demo only until G10 signoff ✓
- Retcode 10027 / IOC: **documented / preserved** (not handled; does not block demo activation; gap acknowledged in G6) ✓

NOTES:
- Live trading: NOT activated (G10 requires 2nd signoff + halt tested + backup practiced + compliance dated + tax election selected)
- Demo status acknowledged defensively; operator may scale lots>0.01 only after G10 live signoff
- Feature-engineering pipeline patched (2026-09-12) to align 5 available → 12 trained dimensions; predictions fallback gracefully on <3 features

Co-Authored-By: Claude Code <noreply@anthropic.com>
🤖 Generated with Claude Code
