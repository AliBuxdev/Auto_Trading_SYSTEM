def set_seed(seed=42):
    import random, numpy as np
    random.seed(seed)
    np.random.seed(seed)

def byte_reproducible():
    return {"seed": 42, "fixed_weights": True, "run_id": "v2-" + hex(42)}