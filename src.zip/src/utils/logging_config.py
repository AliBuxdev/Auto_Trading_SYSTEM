import logging, json, time

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

def log_run(run_id, phase, message):
    logging.info(json.dumps({"run_id": run_id, "phase": phase, "message": message, "ts": time.time()}))

def log_experiment(experiment_id, config):
    logging.info(json.dumps({"experiment_id": experiment_id, "config": config}))