"""
Step 17: Orchestrator — fixed weights, byte-reproducible
Controls promotion Gate 3 → Gate 10; fixed weights, not meta-learned.
"""

from src.risk.engine import CAPS, ProjectStopLoss
from src.execution.paper_engine import PaperEngine
from src.agents.agent2_gradient_boosting import GradientBoostingPredictive

FIXED_WEIGHTS = {"EURUSD": 0.30, "XAUUSD": 0.25, "XAGUSD": 0.20, "DXY": 0.25}
TIER = 1  # current tier


class Orchestrator:
    def __init__(self):
        self.risk_engine = ProjectStopLoss(threshold_pct=10.0)
        self.execution = PaperEngine()
        self.predictive = GradientBoostingPredictive()
        self.run_id = "v2-build-20260910"

    def run_cycle(self, features_per_market: dict) -> dict:
        """Single orchestration cycle: predict → risk check → execute."""
        decisions = {}
        success = 0
        try:
            for market, weights in FIXED_WEIGHTS.items():
                try:
                    if market not in features_per_market:
                        continue
                    df = features_per_market[market]
                    if df is None or len(df) == 0:
                        continue
                    # Risk gate: 2% daily DD (enforced) + 10% project via engine
                    from src.agents.agent5_risk import RiskAgent
                    agent5 = RiskAgent()
                    # Use REAL equity/peak values from PaperEngine, not dummy hardcoded values
                    peak_equity = getattr(self.execution, 'peak_equity', None) or self.execution.equity
                    current_equity = self.execution.equity if hasattr(self.execution, 'equity') else 10000.0
                    # Compute real daily drawdown from recent returns (last 24 bars ≈ 1 day at 1h interval)
                    if "close" in df.columns and len(df) >= 24:
                        recent_returns = df["close"].pct_change().dropna().tail(24)
                        recent_peak = (1 + recent_returns.cumsum()).cummax()
                        recent_dd = ((recent_peak - (1 + recent_returns.cumsum())) / recent_peak).max() if len(recent_peak) > 0 else 0.0
                        real_daily_dd = float(recent_dd) * 100
                    else:
                        real_daily_dd = 0.0
                    if not agent5.check_project_drawdown(current_equity, peak_equity, daily_dd_pct=real_daily_dd):
                        # Also enforce the 10% project-level stop-loss circuit breaker
                        if self.risk_engine.check(peak_equity, current_equity):
                            print("[ORCH] Project stop-loss triggered (10% cap) — HALT ALL")
                            decisions = {}
                            break
                        continue
                    # Feature-based signal (Agent 2 validated)
                    from src.agents.agent2_gradient_boosting import GradientBoostingPredictive
                    pred = GradientBoostingPredictive().predict_direction(df, 70, 70)
                    if pred["direction"] == "hold":
                        continue
                    last_return = df["close"].pct_change().iloc[-1] if "close" in df.columns else 0
                    direction = pred["direction"] if pred["direction"] in ("long","short") else ("long" if last_return > 0 else "short")
                    decisions[market] = {"direction": direction, "weight": weights}
                    success += 1
                except Exception as e:
                    print(f"[ORCH] Market {market} error ({e}) — skip")
                    continue
            # Circuit-breaker: < 50% markets succeed → HOLD-ALL
            total = len(FIXED_WEIGHTS)
            if success < total * 0.5:
                print(f"[ORCH] CIRCUIT-BREAK: only {success}/{total} markets succeeded — HOLD ALL")
                decisions = {}
            # Execute via paper engine (only if circuit didn't break)
            for market, dec in decisions.items():
                if dec["direction"] != "hold":
                    try:
                        self.execution.submit_order(market, dec["direction"])
                    except Exception as e:
                        print(f"[ORCH] Execution fail for {market}: {e}")
        except Exception as e:
            print(f"[ORCH] Cycle crash ({e}) — holding all")
            decisions = {}
        return {"run_id": self.run_id, "decisions": decisions, "positions": self.execution.positions, "tier": TIER, "success_markets": success}
