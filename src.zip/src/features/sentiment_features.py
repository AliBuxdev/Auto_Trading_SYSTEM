"""
Step 11: Sentiment features (aggregate + lag + z-score)
"""

import pandas as pd

def compute_sentiment_features(df: pd.DataFrame, sentiment_scores: list[float]) -> pd.DataFrame:
    df = df.copy()
    if sentiment_scores:
        df["sentiment_raw"] = sentiment_scores[:len(df)]
        df["sentiment_lag_1h"] = df["sentiment_raw"].shift(1)
        std_val = df["sentiment_raw"].std()
        df["sentiment_z"] = (df["sentiment_raw"] - df["sentiment_raw"].mean()) / std_val if std_val and std_val != 0 else 0.0
    else:
        df["sentiment_raw"] = 0.0
        df["sentiment_lag_1h"] = 0.0
        df["sentiment_z"] = 0.0
    return df