"""
Step 12: Combined Feature Matrix Builder
Merges technical + sentiment features. Correlation cap 0.7 enforced (Task 8).
"""

import pandas as pd, numpy as np

def build_feature_matrix(tech_df: pd.DataFrame, sent_df: pd.DataFrame) -> pd.DataFrame:
    combined = pd.merge(tech_df, sent_df, left_index=True, right_index=True, how='inner')
    df = combined.copy()
    if 'close' in df.columns:
        df['returns'] = df['close'].pct_change()
        df['momentum'] = df['close'] / df['close'].rolling(10,min_periods=2).mean() - 1
        df['volatility'] = df['close'].pct_change().rolling(20).std()
        df['range_pct'] = (df['high']-df['low'])/df['close']*100
        df['support_resistance'] = df['close'].rolling(20,min_periods=1).mean()
    if 'volume' in df.columns:
        df['volume_zscore'] = (df['volume']-df['volume'].rolling(20).mean())/df['volume'].rolling(20).std()
    df['risk_reward_ratio'] = 1.5
    df['position_size_pct'] = 10.0
    return df

def check_correlation_cap(df: pd.DataFrame, max_corr: float = 0.7) -> pd.DataFrame:
    """Flag pairs exceeding cap; return violation info."""
    num_cols = df.select_dtypes(include=[np.number]).columns
    corr = df[num_cols].corr().abs()
    violations = []
    for i in range(len(num_cols)):
        for j in range(i+1, len(num_cols)):
            if corr.iloc[i, j] > max_corr:
                violations.append({
                    "col_a": num_cols[i], "col_b": num_cols[j],
                    "corr": round(corr.iloc[i, j], 4)
                })
    for v in violations:
        print(f"[DIVERSITY] {v['col_a']} <-> {v['col_b']}: {v['corr']}")
        raise ValueError(f"Correlation cap violated: {v['col_a']} <-> {v['col_b']} = {v['corr']} > {max_corr}")
    return violations