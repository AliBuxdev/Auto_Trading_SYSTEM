"""
Step 10: Technical indicators (RSI, MACD, Bollinger, ATR)
Uses cached 1h data.
"""

import pandas as pd, numpy as np

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = (-delta.clip(upper=0))
    avg_gain = gain.ewm(alpha=1/period, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1/period, min_periods=period).mean()
    # Zero-guard: avoid division by zero when no losses (flat market)
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rs = rs.fillna(0)  # flat/no-loss window → RSI = 100 (full uptrend signal) or 0 depending on convention; here neutral-strong
    return 100 - (100 / (1 + rs))

def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    ema_f = series.ewm(span=fast, adjust=False).mean()
    ema_s = series.ewm(span=slow, adjust=False).mean()
    macd_line = ema_f - ema_s
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    return macd_line, signal_line

def bollinger(series: pd.Series, period: int = 20, k: float = 2.0):
    ma = series.rolling(window=period).mean()
    std = series.rolling(window=period).std()
    return ma + k*std, ma - k*std

def atr(series_high: pd.Series, series_low: pd.Series, series_close: pd.Series, period: int = 14) -> pd.Series:
    # True ATR: max(high-low, |high-prev_close|, |low-prev_close|) rolling mean
    high_low = series_high - series_low
    high_prev_close = (series_high - series_close.shift(1)).abs()
    low_prev_close = (series_low - series_close.shift(1)).abs()
    true_range = pd.concat([high_low, high_prev_close, low_prev_close], axis=1).max(axis=1)
    return true_range.rolling(window=period).mean()

def compute_technical(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["rsi_14"] = rsi(df["close"])
    macd_line, signal_line = macd(df["close"])
    df["macd"] = macd_line
    df["macd_signal"] = signal_line
    upper, lower = bollinger(df["close"])
    df["bollinger_upper"] = upper
    df["bollinger_lower"] = lower
    df["atr_14"] = atr(df["high"], df["low"], df["close"])
    return df
