"""
Step 6: YFinance 1h OHLCV Fetcher with retry logic
Gate 2: append-only store, future-leak guard, clock sync ≤100ms
"""

import yfinance as yf
import pandas as pd
import time
from datetime import datetime
from pathlib import Path

DATA_DIR = Path("src/data/store")
DATA_DIR.mkdir(parents=True, exist_ok=True)

STORE_PATH = DATA_DIR / "forex_1h.parquet"


def fetch_1h(symbol: str, days_back: int = 730, max_retries: int = 3) -> pd.DataFrame:
    """
    Fetch 1h OHLCV from yfinance with retry + throttle.
    Returns raw DataFrame (no future leak yet — caller must validate).
    """
    ticker = yf.Ticker(symbol)
    df = None

    for attempt in range(1, max_retries + 1):
        try:
            df = ticker.history(period=f"{days_back}d", interval="1h")
            if df is not None and not df.empty:
                break
        except Exception as e:
            print(f"[FETCH] {symbol} attempt {attempt}/{max_retries} failed: {e}")

        # Throttle: ~60 req/min burst safe
        time.sleep(1.5)

    if df is None or df.empty:
        raise ValueError(f"[FETCH] No data returned for {symbol}")

    # Standardize columns
    df = df.reset_index()
    df.columns = [c.lower().replace(" ", "_") for c in df.columns]

    # Drop dividends/splits if present
    for col in ["dividends", "stock_splits", "capital_gains"]:
        if col in df.columns:
            df.drop(columns=[col], inplace=True)

    df["symbol"] = symbol
    return df


def future_leak_guard(df: pd.DataFrame) -> pd.DataFrame:
    """Reject any record with timestamp > now. Gate 2."""
    # yfinance index is Datetime; after reset_index -> 'datetime'; normalize to lowercase
    df = df.rename(columns={"Datetime": "date", "datetime": "date"})
    if "date" not in df.columns:
        # Fallback if reset_index produced different name
        for c in df.columns:
            if c.lower() in ("date", "datetime", "timestamp"):
                df = df.rename(columns={c: "date"})
                break
    if "date" not in df.columns and "Date" in df.columns:
        df = df.rename(columns={"Date": "date"})
    now = datetime.now().astimezone()  # aware for comparison with aware timestamps
    df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
    clean = df[df["date"] <= now]
    rejected = len(df) - len(clean)
    if rejected > 0:
        print(f"[LEAK GUARD] {rejected} records rejected (future timestamp)")
    return clean


def id_chain(df: pd.DataFrame) -> pd.DataFrame:
    """Gate 2 forensic trace: source_timestamp + symbol + interval + bar_open."""
    df["record_id"] = (
        df["date"].astype(str) + "_" + df["symbol"] + "_1h_" + df["open"].round(5).astype(str)
    )
    return df


def append_to_store(df: pd.DataFrame) -> pd.DataFrame:
    """Append-only write to parquet store. Merge by record_id to avoid duplicates."""
    if STORE_PATH.exists():
        existing = pd.read_parquet(STORE_PATH)
        combined = pd.concat([existing, df], ignore_index=True)
        combined = combined.drop_duplicates(subset=["record_id"], keep="last")
        combined = combined.sort_values("date").reset_index(drop=True)
    else:
        combined = df.sort_values("date").reset_index(drop=True)

    combined.to_parquet(STORE_PATH, index=False)
    print(f"[STORE] Wrote {len(combined)} records to {STORE_PATH}")
    return combined


def fetch_all(symbols: dict) -> pd.DataFrame:
    """Fetch all markets from symbols config. Returns combined clean store."""
    all_frames = []
    for name, info in symbols.items():
        print(f"\n[FETCH] {name} ({info['ticker']})...")
        raw = fetch_1h(info["ticker"])
        clean = future_leak_guard(raw)
        clean = id_chain(clean)
        all_frames.append(clean)

    combined = pd.concat(all_frames, ignore_index=True)
    store = append_to_store(combined)
    print(f"\n[FETCH] All {len(symbols)} markets fetched. Store: {len(store)} rows.")
    return store


if __name__ == "__main__":
    from src.utils.logging_config import setup_logging
    setup_logging()

    symbols = {
        "EURUSD": {"ticker": "EURUSD=X"},
        "XAUUSD": {"ticker": "GC=F"},
        "XAGUSD": {"ticker": "SI=F"},
        "DXY": {"ticker": "DX-Y.NYB"},
    }
    fetch_all(symbols)
