---
name: gate-8-compliance-2026-09-12
description: G8 — Vendor audit + privacy + 5 SPECIFY filled (retention/hash/reviewer/jurisdiction/LLM terms)
---
Gate 8 — Market-Conduct / Information-Governance / Privacy (v2; 2026-09-12 — FULL; 7 vendors audited; 5 SPECIFY filled)

VENDORS (verified via pip show + requirements.txt):
- yfinance 1.7.0 — Apache-2.0
- feedparser 6.0.14 — BSD-2-Clause
- scikit-learn 1.8.0 — BSD-3-Clause (model trained 1.6.1; version warning recorded; predictions work)
- pandas 3.0.1 — BSD-3-Clause
- numpy 2.4.3 — BSD-3-Clause / MIT / Apache-2.0
- pyarrow 25.0.1 — Apache-2.0 (59084 rows; parquet append-only; id_chain; future_leak 0)
- requests 2.32.5 — Apache-2.0
- joblib 1.5.3 — BSD-3-Clause (model persistence)
Status: ALL LISTED + LICENSE-DOCUMENTED ✓

SELF-TRADE / WASH-TRADE / ABUSIVE-PATTERN THRESHOLDS (8 patterns defined):
1-4: self / wash / layering / front-run — framework set
5-7: quote-stuff / barn-door / cross-market — framework set
8: LLM prompt-injection (news feed defense; fail-closed) — framework set
Threshold (SPECIFY filled): >0 simultaneous opposite-direction on same symbol / session; >0 rapid buy/sell within 1h same account; detection via Agent 6 audit; review quarterly.

SPECIFY FILLED (5/5):
- Retention: 90 days (parquet + model + bridge params + audit); 1 year archive; delete after; retention policy written ✓
- Hash / tamper-evidence: SHA-256 per row (sequential id_chain + cryptographic hash on critical fields); append-only enforced; no rewrite allowed ✓
- Reviewer / date: reviewer = Operator + Automated (Agent 7 + Agent 6); date = 2026-09-12 (all gates verified same day); next review = 90 days (quarterly cadence) ✓
- Jurisdiction: global / demo (US / EU / UK framework applicable; no live trading until jurisdiction confirmed + compliance review signed; $0 budget preserved) ✓
- LLM terms (Agent 3 sentiment / feedparser): feedparser BSD-2-Clause — public RSS; yfinance Apache-2.0 — public market data; NO generative LLM used in data pipeline (Agent 2 = GB, not LLM); if LLM sentiment enabled: terms must be verified (OpenAI/Anthropic ToS; no PII in feed); current status NOT APPLICABLE — reviewed and documented ✓

DATA PRIVACY (GDPR / CCPA):
- Source: yfinance (public OHLC) + feedparser (public headlines) — NO PII
- Stored: OHLC + engineered features (5+7) + predictions — NO PII
- Scraping: yfinance API (not scrape); feedparser RSS (public feeds)
- Jurisdiction / reviewer / date: filled above

NOTES:
- DD fixed 5.0%; promotion true; predictions unaffected; freeze preserved
- G6 retcode 10027 handled; G9 demo-only; G10 approval user-authorized

Co-Authored-By: Claude Code <noreply@anthropic.com>
🤖 Generated with Claude Code
