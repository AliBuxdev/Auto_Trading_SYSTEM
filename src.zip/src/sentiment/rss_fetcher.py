"""
Step 8: Free RSS Aggregator (forex/news)
No API key; fails closed if feeds unreachable.
"""

import feedparser
from datetime import datetime

FEEDS = [
    "https://www.investing.com/rss/news_285.rss",  # investing.com forex news
    "https://www.kitco.com/rss/gold.xml",           # Kitco gold
    "https://www.reuters.com/business/finance/rss", # Reuters finance
]


def fetch_rss(feed_url: str, timeout: int = 10):
    # Note: feedparser.parse(timeout=...) unsupported in some versions; handled defensively
    try:
        parsed = feedparser.parse(feed_url, request_headers={"User-Agent":"Mozilla/5.0"})
        return [
            {"title": entry.get("title", "").strip(),
             "summary": entry.get("summary", "").strip()[:500],
             "published": entry.get("published", ""),
             "link": entry.get("link", "")}
            for entry in parsed.entries[:20]
        ]
    except Exception as e:
        print(f"[RSS] Failed {feed_url}: {e}")
        return []


def aggregate_headlines() -> list[dict]:
    all_entries = []
    for url in FEEDS:
        all_entries.extend(fetch_rss(url))
    # Deduplicate by title
    seen = set()
    unique = []
    for e in all_entries:
        if e["title"] not in seen and e["title"]:
            seen.add(e["title"])
            unique.append(e)
    return unique
