"""
Step 9: LLM sentiment scoring (Ollama local, $0, no API key)
Shadow + fallback; temporal leak guard (LLM version tracked)
"""

import requests, json
from datetime import datetime

LLM_VERSION = "ollama-llama3-2"  # tracked for Gate 2 temporal guard
MODEL_NAME = "llama3.2"
URL = "http://localhost:11434/api/generate"

STALENESS_THRESHOLD = 20  # seconds (Task 3 / Gate 4)
SHADOW_DIVERGENCE = 0.1
LLM_VERSION = "ollama-llama3-2"  # tracked for temporal guard

def score_sentiment(text: str, llm_version: str = LLM_VERSION) -> float:
    """Return sentiment score in [-1, +1]. Fail-closed: if LLM unavailable, return 0 (neutral)."""
    try:
        prompt = f"[model={llm_version}] Score sentiment... \"{text}\""
        resp = requests.post(URL, json={
            "model": MODEL_NAME,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.1}
        }, timeout=15)
        if resp.status_code == 200:
            text = resp.json().get("response", "").strip()
            # Extract first float-like token
            for token in text.split():
                try:
                    v = float(token)
                    if -1.0 <= v <= 1.0:
                        return v
                except ValueError:
                    continue
            return 0.0  # couldn't parse
        else:
            return 0.0  # fail-closed
    except Exception:
        return 0.0  # fail-closed (stale/unavailable)


def compute_aggregate(headlines: list[dict]) -> float:
    scores = [score_sentiment(h.get("title", ""), llm_version=LLM_VERSION) for h in headlines if h.get("title")]
    if not scores:
        return 0.0
    return sum(scores) / len(scores)
