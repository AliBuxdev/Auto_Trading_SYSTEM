---
name: gate-5-risk-limits-2026-09-12
description: G5 — Risk / execution limits fully set; 8 caps + correlation cap 0.7 + DD cap 10% + SPECIFY filled
---

Gate 5 — Risk / Execution Limits (v2; 2026-09-12 — FULL, all SPECIFY filled; freeze contract preserved)

CONFIRMED CAPS (freeze contract / MASTER_PLAN.md):
1. Lots: 0.01 (constant) ✓
2. TP: 4% + system-boosted ✓
3. Trades/day: 10 max + boosted ✓
4. DD cap (per-trade): 2% (Agent 5) ✓
5. DD cap (project-level): 10% (freeze / Agent 5 / G10) ✓
6. Correlation cap (diversity): max 0.7 (G3 / Agent 2 / freeze) ✓
7. Markets: 4 (XAUUSD primary, XAGUSD secondary, EURUSD, DXY) ✓
8. Sessions: 4 (ForexFactory A=4h/12h, B=1h/4h London-NY) ✓

SPECIFY FILLED (all concrete, no blanks — derived from freeze / MASTER_PLAN.md / user signoff):
- DD cap value: 10.0% (project-level) ✓
- DD check frequency: continuous (Agent 5 + Agent 7 circuit-break; real-time per order) ✓
- SL mechanism: fixed % + dynamic (Agent 5 2% cap per trade; Agent 7 partial-failure) ✓
- Lot sizing rule: fixed 0.01 (no meta-learning; byte-reproducible) ✓
- TP mechanism: 4% base + confidence boost (Agent 2 allocation_pct scaled by confidence * 1.5) ✓
- Trade frequency cap: 10/day + system-boosted (boost based on promotion state + session match) ✓
- Market set: 4 (XAUUSD / XAGUSD / EURUSD / DXY) — freeze preserved ✓
- Session rules: 4 (ForexFactory A + B; London-NY overlap) ✓
- Correlation cap enforcement: 0.7 max (Agent 3 correlation agent; diversity filter applied) ✓
- Capital allocation per market: split by confidence % (Agent 2 allocation_pct scaled) ✓
- Halt on DD: automatic (Agent 5 2% → hold; Agent 7 circuit-break; manual key available) ✓
- Backup execution: MQL5 bridge `active=True` (demo 112428850); live deferred to G10 signoff ✓

NOTES / PRESERVED GAPS:
- G10 live authorization requires 2nd signoff + halt tested (FINAL documented; GO-NO-GO records unverified)
- Freeze: $0 budget; public APIs only (yfinance / feedparser)
- Dynamic rules preserved: 0.01 / 4%+boost / 10+boost / 0.7 / 4 markets / 4 sessions / 300 search / 2/3 promotion / deflated_sharpe + bonferroni
- DD fix: 5.0% / promoted=true (Agent 2 promotion enabled; metrics consistent)

Co-Authored-By: Claude Code <noreply@anthropic.com>
🤖 Generated with Claude Code
