"""
Step 15: Risk Engine — 8 caps + 10% project stop-loss
Gate 5: hard circuit breaker (manual re-enable only)
"""

import numpy as np

CAPS = [
    {"name": "max_daily_loss_pct", "value": 2.0},
    {"name": "max_position_pct", "value": 5.0},
    {"name": "max_correlation", "value": 0.7},
    {"name": "max_drawdown_pct", "value": 10.0},
    {"name": "min_sharpe", "value": 1.0},
    {"name": "max_holding_hours", "value": 72},
    {"name": "min_win_rate", "value": 0.45},
    {"name": "max_trades_per_day", "value": 10},
]
PROJECT_STOP_LOSS_PCT = 10.0


def check_caps(metrics: dict) -> list[str]:
    violations = []
    for cap in CAPS:
        if cap["name"] in metrics and metrics[cap["name"]] > cap["value"]:
            violations.append(f"CAP BREACH: {cap['name']} = {metrics[cap['name']]} > {cap['value']}")
    return violations


class ProjectStopLoss:
    """Hard circuit breaker — manual re-enable only."""
    def __init__(self, threshold_pct: float = 10.0):
        self.threshold_pct = threshold_pct
        self.triggered = False

    def check(self, peak_equity: float, current_equity: float) -> bool:
        if peak_equity <= 0:
            return False
        drawdown_pct = (peak_equity - current_equity) / peak_equity * 100
        if drawdown_pct >= self.threshold_pct:
            self.triggered = True
            return True
        return False

    def reset(self):
        """Manual re-enable after root-cause review."""
        self.triggered = False
