"""
Step 14: Validator — Bonferroni correction (alpha/300) + block bootstrap
Promotion thresholds: Sharpe > 1.0, max DD < 10%, PF > 1.5 (2/3 required)
Acceptance floor: lower 95% CI Sharpe > 0
"""

import numpy as np

def bonferroni_alpha(alpha: float = 0.05, n_tests: int = 300) -> float:
    return alpha / n_tests

def deflated_sharpe_ratio(returns: np.ndarray, n_obs: int) -> float:
    """Simple deflated Sharpe approximation (requires 1000+ for power)."""
    if len(returns) < 100:
        return 0.0  # insufficient
    mean_r = np.mean(returns)
    std_r = np.std(returns, ddof=1)
    if std_r == 0:
        return 0.0
    sharpe = mean_r / std_r * np.sqrt(252)  # annualized approx
    # Deflation factor (simplified)
    deflated = sharpe - (0.1 + 0.1 * np.log(n_obs / 1000)) if n_obs < 1000 else sharpe
    return deflated

PROMOTION = {"sharpe": 1.0, "max_dd": 0.10, "profit_factor": 1.5, "required_of_3": 2}
