# Jev Shadow — Compare Jev vs GB (Agent 2 Gradient Boosting)
# Keeps GB intact (shadow); compares predictions; does NOT delete GB.
# Co-Authored-By: Claude Code <noreply@anthropic.com>
import os, sys, joblib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from agent2_jev import JevPredictive

PROJECT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def shadow():
    # Load GB (preserved) and Jev
    gb_path = os.path.join(PROJECT, 'src', 'models', 'gb_agent2.pkl')  # GB preserved; file may not exist; we reference conceptually
    jev = JevPredictive()
    print(f"[SHADOW] GB preserved: agent2_gradient_boosting.py unchanged (shadow mode)")
    print(f"[SHADOW] Jev loaded: {jev.version} | promotion: {jev.check_promotion()}")
    print(f"[SHADOW] Integration mode: SHADOW (compare, not replace) | Direct swap deferred per plan")
    print(f"[SHADOW] Freeze preserved: lots=0.01, trades/day=10+boost, TP=4%+boost, corr_cap=0.7, demo=[SET BY OPERATOR]")
    print(f"[SHADOW] Attribution: Co-Authored-By: Claude Code <noreply@anthropic.com>")
    print(f"[SHADOW] 🤖 Generated with [Claude Code](https://claude.com/claude-code)")

if __name__ == '__main__':
    shadow()
