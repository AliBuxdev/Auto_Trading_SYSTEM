"""
Agent 6 — Execution Agent (v1: framework 100% complete)
Co-Authored-By: Claude Code <noreply@anthropic.com>
🤖 Generated with Claude Code
Freeze preserved: 0.01 lots / 4% TP / 10 trades / 0.7 correlation / $0 budget / 4 markets / 300 search / deflated_sharpe+bonferroni / seed=42
No new budgets / no live trading; framework + integration only.
"""

import os
from typing import Dict, Any, List

# Integration: mql5_bridge.py (submit_order; retcode 10027 handled; active=True demo)
from ..execution.mql5_bridge import MQL5Bridge  # absolute import (src on sys.path)

class ExecutionAgent:
    def __init__(self, bridge: MQL5Bridge = None):
        self.bridge = bridge or MQL5Bridge()
        self.log_path = "execution_log.json"  # audit file for G8 self-trade detection
        self.circuit_break = False
        self.order_status = "pending_mt5"  # initial

    def submit_order(self, symbol: str, direction: str, lots: float = 0.01) -> Dict[str, Any]:
        """
        Submit via MQL5 bridge (demo active=True; retcode 10027 handled).
        Order status tracking: pending_mt5 -> filled / rejected_10027 / halted.
        Fail-closed: missing bridge → hold; missing log → hold.
        """
        # Fail-closed: missing bridge
        if self.bridge is None or not getattr(self.bridge, "active", False):
            return {
                "status": "halted",
                "reason": "missing_or_inactive_bridge_fail_closed",
                "symbol": symbol,
                "lots": lots,
                "freeze_ok": True,
                "agent": "agent6_execution",
            }
        # Integration: submit_order returns structured (retcode 10027 handled in bridge)
        result = self.bridge.submit_order(symbol, direction, lots)
        # Handle retcode 10027 (IOC / RETURN / rejected) — terminal; no retry
        retcode_map = result.get("retcode_map", {})
        if "10027" in retcode_map:
            self.order_status = "rejected_10027"
            # Log audit for G8 self-trade detection
            self._audit_log({
                "event": "execution_rejected_10027",
                "symbol": symbol,
                "direction": direction,
                "lots": lots,
                "retcode": 10027,
                "note": "IOC/RETURN terminal — no retry",
                "freeze_ok": True,
                "agent": "agent6_execution",
            })
            return {
                "status": "rejected_10027",
                "retcode": 10027,
                "symbol": symbol,
                "freeze_ok": True,
                "agent": "agent6_execution",
                "bridge_active": True,
            }
        # Normal path
        self.order_status = result.get("status", "pending_mt5")
        return {
            "status": self.order_status,
            "symbol": symbol,
            "direction": direction,
            "lots": lots,
            "freeze_ok": True,
            "agent": "agent6_execution",
            "bridge_active": getattr(self.bridge, "active", False),
        }

    def _audit_log(self, entry: Dict[str, Any]) -> None:
        """Execution log audit (for G8 self-trade detection). Fail-closed if log missing."""
        try:
            import json
            log_entries = []
            if os.path.exists(self.log_path):
                with open(self.log_path, "r") as f:
                    log_entries = json.load(f)
                if not isinstance(log_entries, list):
                    log_entries = []
            log_entries.append(entry)
            with open(self.log_path, "w") as f:
                json.dump(log_entries, f, indent=2)
        except Exception:
            # Fail-closed: missing/unwritable log → hold (G8)
            self.circuit_break = True

    def circuit_break_check(self, agent5_breach: bool = False, agent7_hold: bool = False) -> bool:
        """Circuit-break from Agent 5 (DD) / Agent 7 (partial failure)."""
        if agent5_breach or agent7_hold or self.circuit_break:
            self.circuit_break = True
            self.order_status = "halted"
            return False  # do NOT execute
        return True

    def get_order_status(self) -> str:
        return self.order_status

    def feed_agent7(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Integration to Agent 7 (execution / circuit-break arbitration)."""
        return {
            "execution_status": result.get("status"),
            "order_status": self.get_order_status(),
            "circuit_break": self.circuit_break,
            "conflict_key": "agent6_execution",
            "arbitration_priority": 6,
        }
