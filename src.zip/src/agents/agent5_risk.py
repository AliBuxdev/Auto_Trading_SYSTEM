# Agent 5 — Risk Agent (v2: 8 caps + 10% DD project-level circuit breaker)
# Confirmed 2026-09-09; demo monitored; live-critical at Gate 10

CAPS = {
    "max_daily_drawdown_pct": 2.0,
    "max_weekly_drawdown_pct": 5.0,
    "max_position_pct_per_market": 10.0,
    "max_correlation_exposure": 0.7,
    "max_leverage": 1.0,
    "max_spread_tolerance_pips": 1.0,
    "max_slippage_pips": 2.0,
    "max_trades_per_hour": 5
}

PROJECT_DD_CAP = 10.0  # 10% from peak equity (Task 13)

class RiskAgent:
    def __init__(self):
        self.project_dd_cap = PROJECT_DD_CAP
        self.breach_detected = False

    def check_project_drawdown(self, equity, peak, daily_dd_pct=None):
        # 2% daily cap enforced (Task 4 / freeze rule)
        if daily_dd_pct is not None and daily_dd_pct > CAPS["max_daily_drawdown_pct"]:
            print(f"[RISK] DAILY DD BREACH: {daily_dd_pct:.2f}% > {CAPS['max_daily_drawdown_pct']}% — HALT")
            return False
        dd = (peak - equity) / peak * 100
        if dd >= self.project_dd_cap:
            print(f"[RISK] DD BREACH: {dd:.1f}% >= {self.project_dd_cap}% — HALT")
            return False
        return True
