// MQL5 Connector — $0 Public-Data Bridge (Agent 6 / Execution)
// Source: yfinance public CSV (not broker feed) → MT5 Demo
// User spec: MT5 via Python; $0 budget; no broker account
// Multi-market: EURUSD + XAUUSD + XAGUSD + DXY
// Confidence formula: avg = (LLM_conf + Strategy_conf) / 2; trade if >= 70% (configurable)

// Notes per v2 audit / council:
// - No fixed TP/SL rules (user: AI decides; parameterized only)
// - Fibonacci only for Strategy B short trades (preserved)
// - Sentiment source: public RSS framework (ForexFactory / Kitco / Reuters / Bloomberg)  # [CONFIRMED 2026-09-12]
// - Server/account: MT5_SERVER = MetaQuotes-Demo; MT5_ACCOUNT = [SET BY OPERATOR]  # [CONFIRMED 2026-09-12]
// - retcode 10027 / IOC / RETURN / ORDER_TYPE_IOC — not handled; Gate 6 fault injection pending
// - Conflict resolution: A(long) vs B(short) — not yet defined; add arbitration logic

#include <Trade\Trade.mqh>

input string DataFeedPath = "src/data/store/forex_1h.csv";  // yfinance append-only
input int    ConfidenceThreshold = 70;                       // % — configurable (default 70)
input double LotSize = 0.01;                                  // confirmed Task 1

// Per-market confidence (AI-calculated from LLM + strategy ratios + news + predictions)
double conf_EURUSD = 0, conf_XAUUSD = 0, conf_XAGUSD = 0, conf_DXY = 0;

// Action: take trade in direction (long = Strategy A / short = Strategy B) if avg >= threshold
// Direction chosen by which strategy has higher combined confidence; allocation % across cluster
void OnTick()
{
   // Read CSV + compute per-market avg
   // Execute if confidence >= threshold
   int handle = FileOpen(DataFeedPath, FILE_READ|FILE_WRITE|FILE_COMMON);
   if(handle != INVALID_HANDLE)
   {
      FileClose(handle);
      // Trade execution framework (demo only, no live capital at risk)
      // Arbitration: resolve A vs B conflict per Gate 6
   }
}
{
   // Read CSV + compute per-market avg = (LLM + Strategy) / 2
   // If avg >= ConfidenceThreshold → execute via MT5 demo (no live capital at risk)
   // If A and B disagree → arbitration needed (council caught this gap)
   // Log experiment_id for registry (Gate 9 / Agent 2 reproducibility)
}

// === PATCH — Agent 6 Execution: Fault-Injection Paper Trading + Reconciliation ===
// Add rejection/retry/gap scenarios to test matrix (Gate 6 / Task 6)
// Watchdog: silent or divergence > SLA triggers alert
// Dashboard: thresholds / SLAs — alert delivery required
// Restart reconciliation: divergence vs expected; failure if unreconciled > threshold
// Shared-fate docs: separate host / cloud-function option documented (v2)
